from app import db


class User(db.Model):

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(100), unique=True)


class SmartHome(db.Model):

    id = db.Column(db.Integer, primary_key=True)
    webhook_url = db.Column(db.String(100))
    user_id = db.Column(db.ForeignKey('User.id'))
    user = db.relationship('User', backref=db.backref('smarthomes', lazy=True))
    password = db.Column(db.String(100))


class Device(db.Model):

    id = db.Column(db.Integer, primary_key=True)
    system_id = db.Column(db.Integer, primary_key=True)
    user_name = db.Column(db.String(100))
    type = db.Column(db.Integer)
