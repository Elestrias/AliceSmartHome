from app import app
from flask import request
import json
import logging
from extra import *


logging.basicConfig(level=logging.DEBUG, filename='server.log', format='%(asctime)s %(levelname)s %(name)s %(message)s')
log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)
logging.info('New user added<br>')


@app.route('/post')
def post():
    response = {
        'session': request.json['session'],
        'version': request.json['version'],
        'response': {
            'end_session': False
        }
    }
    handle_dialog(request.json, response)
    return json.dumps(response)


@app.route('/console')
def console():
    with open('server.log', mode='r') as f:
        data = f.read()
    return data


def handle_dialog(request, response):

    user_id = request['session']['user_id']

    if request['session']['new']:
        if is_user_exists(request['session']['user_id']):
            response['response']['text'] = 'Добро пожаловать обратно!'
            logging.info('User logged in<br>')
        else:
            response['response']['text'] = 'Добро пожаловать в систему Умный Дом! Если вам требуется помощь, напишите "помощь"'
            logging.info('New user registered<br>')
        return


app.run(host='127.0.0.1', port=8080, debug=False)
